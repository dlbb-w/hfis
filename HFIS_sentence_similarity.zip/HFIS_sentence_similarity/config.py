import os
import gensim
root_path = os.path.abspath(os.path.dirname(__file__))

embedding_path = os.path.join(root_path + "/model/embedding/w2v_300_MAS.bin")
vec_model = gensim.models.KeyedVectors.load_word2vec_format(embedding_path, binary=False)

