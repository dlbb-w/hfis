from flask import Flask, request, abort
import numpy as np
import json
app = Flask(__name__)
import os
import sys
sys.path.append("/home/zhao/HFIS_sentence_similarity/src")
sys.path.append("/home/zhao/HFIS_sentence_similarity/service")



from src.utils import cut_sentence
from src.ML.sim_wordvec import SimWordVec
from src.recall.recall_pysparnn import Recall_PySparNN




simw2v = SimWordVec()
recall = Recall_PySparNN()

@app.route('/split_word',methods=['POST'])
def split_word_service():
    """
    函数说明：工单分词，获取工单词向量接口
    json格式{"id": 12345, "content": "content"}
    :return:
    """
    if "POST" == request.method:
        req = request.data
    else:
        abort("405")
    try:
        params = str(req.decode())
        json_obj = json.loads(params)
        id = json_obj["id"]
        content = json_obj["content"]
        cuted_content = cut_sentence.cut(content, by_word=False, use_stopword=True)
        sentence_vec = simw2v.get_sentence_vec(content)
    except Exception as err:
        abort(500)
    response = {}
    response["id"] = str(id)
    response["cuted_content"] = str(cuted_content)
    response["sentence_vec"] = list(sentence_vec)

    return json.dumps(response)


@app.route("/similarity", methods=["POST"])
def similarity_service():
    """
    函数说明：查询相似工单
    json格式{"query":{"id":"", "sentence_vec":""}, "candidate":[{"id":"", "sentence_vec":""}, {"id":"", "sentence_vec":""}}]
    :return:
    """
    if "POST" == request.method:
        req = request.data
    else:
        abort("405")
    try:
        params = str(req.decode())
        json_obj = json.loads(params)
        query = json_obj["query"]
        candidate = json_obj["candidate"]
        id_list = []
        sentence_vec_list = []
        response = {}
        for can in candidate:
            id_list.append(can["id"])
            sentence_vec_list.append(can["sentence_vec"])
        results = recall.recall_service_api(query["sentence_vec"], range(len(id_list)), sentence_vec_list)
    except Exception as err:
        abort(500)

    similarity_list = []
    for result in results:
        for index in result:
            res = {}
            sim = simw2v.similarity_cosine_api(np.array(query["sentence_vec"]), np.array(sentence_vec_list[int(index)]))
            res["id"] = id_list[int(index)]
            res["sim"] = sim
            similarity_list.append(res)
    response["result"] = similarity_list

    return json.dumps(response)




if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8000)

