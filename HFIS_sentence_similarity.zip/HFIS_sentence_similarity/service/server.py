from flask import Flask, request, abort
import numpy as np
import json
app = Flask(__name__)
import sys
import time
import os
cur_path = os.path.abspath(os.path.dirname(__file__))
print("cur_path = ", cur_path)
root_path = os.path.split(cur_path)[0]
print("root_path = ", root_path)
sys.path.append(root_path)

from src.utils import cut_sentence
from src.ML.sim_wordvec import SimWordVec
from src.recall.recall_pysparnn import Recall_PySparNN
from src.recall.sentence2vec import SentenceVectorizer
import config

import logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

root_path = config.root_path + "/SimLogs/"
rq = time.strftime('%Y%m%d%H%M', time.localtime(time.time()))
log_name = root_path + rq + ".log"
logfile = log_name
fh = logging.FileHandler(logfile, mode='w')
fh.setLevel(logging.DEBUG)  # 输出到file的log等级的开关
# 第三步，定义handler的输出格式
formatter = logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s")
fh.setFormatter(formatter)
# 第四步，将logger添加到handler里面
logger.addHandler(fh)

simw2v = SimWordVec()
sen_vec = SentenceVectorizer()
recall = Recall_PySparNN()



@app.route('/split_word',methods=['POST'])
def split_word_service():
    """
    函数说明：工单分词，获取工单词向量接口
    json格式{"id": 12345, "content": "content"}
    :return:
    """
    if "POST" == request.method:
        req = request.data
    else:
        abort("405")
    try:
        params = str(req.decode())
        json_obj = json.loads(params)
        id = json_obj["id"]
        content = json_obj["content"]
        # 分词并计算词向量
        cuted_content = cut_sentence.cut(content, by_word=False, use_stopword=True)
        sentence_vec = simw2v.get_sentence_vec(content)
    except Exception as err:
        logger.error(err)
        abort(500)
    response = {}
    response["id"] = str(id)
    response["cuted_content"] = str(cuted_content)
    response["sentence_vec"] = list(sentence_vec)

    return json.dumps(response)


@app.route("/insert_data", methods=["POST"])
def insert_data():
    """
    函数说明，新增数据插入
    :return:
    """
    if "POST" == request.method:
        req = request.data
    else:
        abort(405)
    try:
        params = str(req.decode())
        json_obj = json.loads(params)
        id = json_obj["id"]
        content = json_obj["content"]
        recall.insert_data(id, content)
        response = {}
        response["result"] = "新数据插入完成"
        return json.dumps(response)
    except Exception as err:
        abort(500)
        logger.error(err)



@app.route("/save_data", methods=["POST"])
def save_data():
    """
    函数说明：定期保存输入的数据
    :return:
    """
    if "POST" == request.method:
        req = request.data
    else:
        abort(405)
    try:
        params = str(req.decode())
        json_obj = json.loads(params)
        run = json_obj["run"]
        if run == "run":
            begin_time = time.time()
            recall.dump_cp()
            end_time = time.time()
            print("耗时：", end_time-begin_time)
            response = {}
            response["result"] = "数据保存完成"
            return json.dumps(response)
    except Exception as err:
        abort(500)
        logger.error(err)




@app.route("/similarity", methods=["POST"])
def similarity_service():
    """
    函数说明：查询相似工单
    json格式{"query":{"id":"", "sentence_vec":""}, "candidate":[{"id":"", "sentence_vec":""}, {"id":"", "sentence_vec":""}}]
    :return:
    """
    if "POST" == request.method:
        req = request.data
    else:
        abort(405)
    try:
        params = str(req.decode())
        json_obj = json.loads(params)
        id = json_obj["id"]
        query = json_obj["content"]
        query_vec = sen_vec.get_sentence_vector(query)
        # 调用召回模块
        candidate = recall.recall_service_api(query)
        result_list = [] # 存放需要返回的数据
        response = {}
        for sentence in candidate[0]:
            temp = sentence.split("@@@")
            temp_dict = {}
            id, content = temp[0], temp[1]
            content_vec = sen_vec.get_sentence_vector(content)
            sim = simw2v.similarity_cosine_api(query_vec, content_vec)
            response[id] = sim
            # temp_dict["id"] = id
            # temp_dict["content"] = content
            # temp_dict["similarity"] = sim
            # result_list.append(temp_dict)

        return json.dumps(response)

    except Exception as err:
        abort(500)
        logger.error(err)




if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5003)

