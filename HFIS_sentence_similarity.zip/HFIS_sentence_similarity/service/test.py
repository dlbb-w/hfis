import requests

base = "http://127.0.0.1:5000/split_word/?inputdata=5.1, 3.5, 1.4, 0.2"
response = requests.get(base)
answer = response.json()
print("预测结果：", answer)

