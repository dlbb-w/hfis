"""
通过SIF算法计算文本之间的相似性
Author: Shubao Zhao
"""
import os
import pickle
import logging
import numpy as np
import config
from gensim import models
from sklearn.decomposition import PCA
from src.preprocess.prepear4SIF import prepear_SIF
logging.basicConfig(format='%(asctime)s:%(levelname)s: %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)


class SIF_weight:
    def __init__(self):
        cur = config.root_path
        self.embedding_filepath = os.path.join(cur, "model/embedding/w2v_300.bin") # word2vec模型路径
        self.word_frequence_path = os.path.join(cur, "model/word_frequence/word_frequence.pkl") # 词频文件保存路径
        self.sentence_list_path = os.path.join(cur, "model/word_frequence/sentence_list.pkl")
        self.principle_component_path = os.path.join(cur, "model/word_frequence/u.pkl")
        if not os.path.exists(self.word_frequence_path or self.sentence_list_path):
            # 如果词频和sentence_list不存在，则获取
            prepear_sif = prepear_SIF()
            prepear_sif.build_word_frequence_dict() # 构建
        self.embedding_model = models.KeyedVectors.load_word2vec_format(self.embedding_filepath, binary=False)
        self.word_frequence_dict = pickle.load(open(self.word_frequence_path, "rb"))
        self.sentence_list = pickle.load(open(self.sentence_list_path, "rb"))
        if not os.path.exists(self.principle_component_path):
            self.build_principle_component_u(embedding_size=300, sentence_list=self.sentence_list)
        self.u = pickle.load(open(self.principle_component_path, "rb"))


    def find_word_frequency(self, word):
        """
        函数说明：给定词word，返回该词在所有文档中的频率
        :param word: 所需要查询的词的频率
        :return:
        """
        dict = self.word_frequence_dict
        return dict[word]


    def get_word_vec(self, word, embedding_size):
        """
        函数说明：给定单词word，返回该词的向量，如果不存在，则填充零
        :param word: 所需要查询的单词
        :param embedding_size: 单词向量的维度
        :return:
        """
        try:
            return self.embedding_model[word]
        except:
            logger.info("word {} out of vocabulary........".format(word))
            return np.zeros(embedding_size)


    def build_principle_component_u(self, embedding_size, sentence_list, a=1e-3):
        """
        函数说明：通过SIF对词向量进行加权求和取平均，最终获得句子向量
        :param embedding_size: 词向量的维度
        :param word_lit: 所有分词后的句子所组成的二维矩阵
        :param a: 参数
        :return:
        """
        sentence_set = []
        for word_list in sentence_list:
            vs = np.zeros(embedding_size) # 初始化句子向量，300维0向量
            sentence_length = len(word_list) # 词的个数
            for word in word_list:
                # smooth inverse frequeny, 计算平滑逆频率
                a_value = a / (a + self.find_word_frequency(word)) # 获取词的权重
                try:
                    # TODO 可能会有异常？
                    vs = np.add(vs, np.multiply(a_value, self.get_word_vec(word, embedding_size=embedding_size))) # 词向量乘以对应的权重
                except:
                    print("invalid sentences")
            vs = np.divide(vs, sentence_length) # 权重求平均
            sentence_set.append(vs)

        # TODO 计算主成分的部分应当存起来，后期以供调用，u可以存入数据库中
        pca = PCA(n_components=embedding_size) # PCA模型
        pca.fit(np.array(sentence_set))
        u = pca.explained_variance_ratio_ # PCA 向量
        u = np.multiply(u, np.transpose(u)) # u * uT

        if len(u) < embedding_size:
            for i in range(embedding_size - len(u)):
                # 如果维度不够，则需要补充零，以进行接下来的乘法
                u = np.append(0)
        # 将第一主成分保存到本地
        pickle.dump(u, open(self.principle_component_path, "wb"))


    def get_sentence_vec(self, embedding_size, word_list, a=1e-3):
        """
        函数说明：获取句子向量
        :param embedding_size: 向量的维度
        :param word_list: 句子分词后的词组成的list
        :return:
        """
        vs = np.zeros(embedding_size)  # 初始化句子向量，300维0向量
        sentence_length = len(word_list) # 词列表的长度
        for word in word_list:
            # smooth inverse frequency 计算平滑逆频率
            a_value = a / (a + self.find_word_frequency(word))
            try:
                # TODO 可能会有异常？
                vs = np.add(vs, np.multiply(a_value, self.get_word_vec(word, embedding_size=embedding_size)))  # 词向量乘以对应的权重
            except:
                print("invalid sentences")
        vs = np.divide(vs, sentence_length)  # 权重求平均
        sentence_vec = np.multiply(self.u, vs)
        sentence_vec = np.subtract(vs, sentence_vec)
        return sentence_vec



if __name__ == '__main__':
    # sif = SimSIF()
    # sentence_list = ["来电人", "反映", "望处理"]
    # sentence_vec = sif.get_sentence_vec(300, sentence_list)
    # print("sentence_vec = ", sentence_vec)
    pass





























