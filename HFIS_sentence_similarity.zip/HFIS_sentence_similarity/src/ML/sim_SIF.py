"""
通过SIF算法对词向量进行加权平均，通过pysparnn进行预排序，最后精排序
Author: Shubao ZHao
"""
import time
import numpy as np
from src.ML.SIF import SIF_weight
from src.recall import recall_pysparnn
from src.utils import cut_sentence

class Sim_SIF:
    def __init__(self):
        pass

    def similarity_cosine(self, vector1, vector2):
        """
        函数说明：基于余弦相似度计算句子之间的相似度，句子向量等于字符向量求平均
        """

        cos1 = np.sum(vector1 * vector2)
        cos21 = np.sqrt(sum(vector1 ** 2))
        cos22 = np.sqrt(sum(vector2 ** 2))
        similarity = cos1 / float(cos21 * cos22)
        return similarity


if __name__ == '__main__':
    rp = recall_pysparnn.Recall_PySparNN(recall_by="SIF_weight")
    begin_time = time.time()
    text1 = "来电人反映马鞍山中加双语学校高一年级，国庆期间仅放假5天，其觉不合理，望处理。"
    results = rp.search(text1.strip(), k=20, k_clusters=8, return_distance=False, recall_by="SIF_weight")
    sim_sif = Sim_SIF()
    sif_weight = SIF_weight()
    text1_list = cut_sentence.cut(text1, by_word=False, use_stopword=True)
    vector1 = sif_weight.get_sentence_vec(300, text1_list)

    for result in results:
        for sentence in result:
            print("sentence = ", sentence)
            sentence_list = cut_sentence.cut(sentence, by_word=False, use_stopword=True)
            vector2 = sif_weight.get_sentence_vec(300, sentence_list)
            sim = sim_sif.similarity_cosine(vector1, vector2)
            print("sim = ", sim)
    end_time = time.time()
    print("time:", end_time - begin_time)
