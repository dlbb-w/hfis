from simhash import Simhash
import jieba.posseg as pseg
from tqdm import tqdm
from similarity_sentence.src.recall import recall_pysparnn
import time


class SimHaming:

    def haming_distance(self, code_s1, code_s2):
        """
         函数说明：利用64位数，计算汉明距离
        :param code_s1:
        :param code_s2:
        :return:
        """
        x = (code_s1 ^ code_s2) & ((1 << 64) - 1)
        ans = 0
        while x:
            ans += 1
            x &= x - 1
        return ans

    def get_similarity(self, a, b):
        """
        函数说明：利用相似度计算方式，计算全文编码相似度
        :param a:
        :param b:
        :return:
        """
        if a > b:
            return b / a
        else:
            return a / b

    def get_features(self, string):
        """
        函数说明：对全文进行分词，提取全文特征，使用词性讲虚词等无关字符去重
        :param string:
        :return:
        """
        word_list = [word.word for word in pseg.cut(string) if word.flag[0] not in ['u','x','w','o','p','c','m','q']]
        return word_list

    def get_distance(self, code_s1, code_s2):
        """
        函数说明：计算两个全文编码的距离
        :param code_s1:
        :param code_s2:
        :return:
        """
        return self.haming_distance(code_s1, code_s2)

    def get_code(self, string):
        """
        函数说明：对全文进行编码
        :param string:
        :return:
        """
        return Simhash(self.get_features(string)).value

    def distance(self, s1, s2):
        """
        函数说明：计算s1与s2之间的距离
        :param s1:
        :param s2:
        :return:
        """
        code_s1 = self.get_code(s1)
        code_s2 = self.get_code(s2)
        similarity = (100 - self.haming_distance(code_s1, code_s2) * 100 / 64) / 100
        return similarity


if __name__ == "__main__":
    rp = recall_pysparnn.Recall_PySparNN()
    simer = SimHaming()
    begin_time = time.time()
    text1 = "来电人反映花山区金汇城市花园西门门口军民路晚间和周末车辆乱停放现象严重，通行不便，建议安装监控探，望采纳。"

    results = rp.search(text1.strip(), k=8, k_clusters=5, return_distance=False)
    for result in results:
        for sentence in result:
            print("sentence = ", sentence)
            sim = simer.distance(text1, sentence)
            print("sim = ", sim)
    end_time = time.time()
    print("time:", end_time - begin_time)


