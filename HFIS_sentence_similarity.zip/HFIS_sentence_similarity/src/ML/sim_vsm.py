"""
说明：基于向量空间模型，通过one-hot编码计算相似度
"""
import math
import numpy as np
import jieba.posseg as pesg
import time
from tqdm import tqdm


class SimVsm:
    def __init__(self, by_word=True):
        self.by_word = by_word

    def distance(self, text1, text2):
        """
        函数说明：比较相似度
        :param text1: 句子1
        :param text2: 句子2
        :return:
        """
        if self.by_word:
            words1 = [word for word in text1]
            words2 = [word for word in text2]
        else:
            words1 = [word.word for word in pesg.cut(text1) if word.flag[0] not in ["u", "x", "w"]]
            words2 = [word.word for word in pesg.cut(text2) if word.flag[0] not in ["u", "x", "w"]]
        tfidf_reps = self.tfidf_rep([words1, words2])
        return self.cosine_sim(np.array(tfidf_reps[0]), np.array(tfidf_reps[1]))

    def tfidf_rep(self, sents):
        """
        函数说明：对句子进行tfidf向量表示
        :param sents:
        :return:
        """
        sent_list = []
        df_dict = {}
        tfidf_list = []
        for sent in sents:
            tmp = {}
            for word in sent:
                if word not in tmp:
                    tmp[word] = 1
                else:
                    tmp[word] += 1
            tmp = {word: word_count / sum(tmp.values()) for word, word_count in tmp.items()}
            for word in set(sent):
                if word not in df_dict:
                    df_dict[word] = 1
                else:
                    df_dict[word] += 1
            sent_list.append(tmp)
        df_dict = {word: math.log(len(sents) / df + 1) for word, df in df_dict.items()}
        words = list(df_dict.keys())
        for sent in sent_list:
            tmp = []
            for word in words:
                tmp.append(sent.get(word, 0))
            tfidf_list.append(tmp)
        return tfidf_list

    def cosine_sim(self, vector1, vector2):
        """
        函数说明：余弦相似度计算
        :return:
        """
        cos1 = np.sum(vector1 * vector2)
        cos21 = np.sqrt(sum(vector1 ** 2))
        cos22 = np.sqrt(sum(vector2 ** 2))
        similarity = cos1 / float(cos21 * cos22)
        return similarity




if __name__ == "__main__":
    text1 = "滨湖新区锦绣淮苑小区业主反映，小区北门武汉路上的滨湖东方汇建筑工地正在施工，夜间大型机械设备作业产生的噪音扰民，望下部门帮助处理。"
    text2 = "下水道堵了"
    sim_vsm = SimVsm(by_word=False)

    begin_time = time.time()
    for i in tqdm(range(1)):
        sim = sim_vsm.distance(text1, text2)
    end_time = time.time()
    print("time:", end_time-begin_time)
    print(sim)