"""
通过对词向量求和取平均，计算句子相似度，并通过pysparnn进行预排序
Author: Shubao Zhao
"""

import numpy as np
import gensim
import jieba

# import sys
# sys.path.append("/home/zhao/HFIS_sentence_similarity/src")
# sys.path.append("/home/zhao/HFIS_sentence_similarity/config")

import os
from src.utils import cut_sentence
from config import root_path,vec_model
# from src.recall import recall_pysparnn
jieba.load_userdict(os.path.join(root_path, "stopwords/dict.txt"))
import time


class SimWordVec:
    def __init__(self, by_word=False):
        self.by_word = by_word


    def get_word_vector(self, word):
        """
        函数说明: 获取词向量
        """
        try:
            return vec_model[word]
        except:
            return np.zeros(300)


    def get_sentence_vec(self, sentence):
        """
        函数说明：获取句子向量
        :param sentence:
        :return:
        """
        if self.by_word:
            sentence_list = [word for word in sentence]
        else:
            sentence_list = cut_sentence.cut(sentence, by_word=False, use_stopword=True)
        sentence_vec = np.zeros(300)
        for word in sentence_list:
            sentence_vec += self.get_word_vector(word)
        sentence_vec = sentence_vec / len(sentence_list)  # 向量求和取平均
        return sentence_vec


    def similarity_cosine(self, sentence1, sentence2):
        """
        函数说明：基于余弦相似度计算句子之间的相似度，句子向量等于字符向量求平均
        """
        vector1 = self.get_sentence_vec(sentence1)
        vector2 = self.get_sentence_vec(sentence2)

        cos1 = np.sum(vector1 * vector2)
        cos21 = np.sqrt(sum(vector1 ** 2))
        cos22 = np.sqrt(sum(vector2 ** 2))
        similarity = cos1 / float(cos21 * cos22)
        return similarity

    def similarity_cosine_api(self, vector1, vector2):
        """
        函数说明：相似度计算API
        :param vector1:
        :param vector2:
        :return:
        """
        cos1 = np.sum(vector1 * vector2)
        cos21 = np.sqrt(sum(vector1 ** 2))
        cos22 = np.sqrt(sum(vector2 ** 2))
        similarity = cos1 / float(cos21 * cos22)
        return similarity



#
# if __name__ == "__main__":
#
#     # begin_time = time.time()
#     rp = recall_pysparnn.Recall_PySparNN()
#     sim_w2v = SimWordVec(by_word=False)
#     begin_time = time.time()
#     text1 = "反映亳州市蒙城县乐土镇养鸭厂环境污染的问题。"
#     results = rp.search(text1.strip(), k=8, k_clusters=8, return_distance=False)
#     # print("results = ", results)
#     for result in results:
#         for sentence in result:
#             print("sentence = ", sentence)
#             sim = sim_w2v.similarity_cosine(text1, sentence)
#             print("sim = ", sim)
#     end_time = time.time()
#     print("time:", end_time-begin_time)
