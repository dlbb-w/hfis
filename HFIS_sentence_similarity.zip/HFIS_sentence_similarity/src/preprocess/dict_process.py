
def process():
    file_path = "F:\workplace\JD_nlp\similarity_sentence\stopwords\demo.txt"
    write_file = "F:\workplace\JD_nlp\similarity_sentence\stopwords\demo2.txt"
    with open(write_file, "w+", encoding="utf-8") as w:
        with open(file_path, 'r', encoding="utf-8") as f:
            for line in f:  # 遍历每一个词，以及他的词向量
                print("line = ", line)
                values = line.strip().strip().split("、")

                for value in values:
                    w.write(value + "\n")
    f.close()
    w.close()


def process2():
    file_path = "F:\workplace\JD_nlp\similarity_sentence\stopwords\demo2.txt"
    write_file = "F:\workplace\JD_nlp\similarity_sentence\stopwords\demo3.txt"
    with open(write_file, "w+", encoding="utf-8") as w:
        with open(file_path, 'r', encoding="utf-8") as f:
            for line in f:  # 遍历每一个词，以及他的词向量
                if len(line) <= 6 and len(line) >= 2:
                    w.write(line)

    f.close()
    w.close()





if __name__ == "__main__":
    # process()
    process2()









