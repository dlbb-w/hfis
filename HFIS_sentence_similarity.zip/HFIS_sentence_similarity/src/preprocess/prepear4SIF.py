"""
对SIF算法所需要的数据进行预处理，包括：
工单的分词，分词后文本数据的存储，分词词频的统计
Author: Shubao Zhao
"""
import os
import config
import pickle
import logging
import pandas as pd
import numpy as np
from tqdm import tqdm
from src.utils import cut_sentence
from collections import defaultdict

logging.basicConfig(format='%(asctime)s:%(levelname)s: %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)


class prepear_SIF:
    def __init__(self):
        cur = config.root_path
        self.path4word_frequence = os.path.join(cur, "datasets/train/训练工单") # 用于统计词频的原始文件的路径
        self.word_frequence_path = os.path.join(cur, "model/word_frequence/word_frequence.pkl")  # 词频文件保存路径
        self.sentence_list_path = os.path.join(cur, "model/word_frequence/sentence_list.pkl") # 用于保存分词后的文本列表
        self.word_frequence_dict = defaultdict(int)  # 记录词汇表词频，defaultdict(int)，参数传int时，dict不存在则返回0


    def build_word_frequence_dict(self):
        """
        函数说明：构建词频字典，每一个分词后的文本存储到sentence_list中
        :return:
        """
        sentence_list = [] # 用于存储每一个
        for root, dirs, files in os.walk(self.path4word_frequence):
            # 遍历每一个数据集
            for file in tqdm(files):
                file_path = os.path.join(root, file)
                if "DS_Store" in file_path:
                    # 排除不必要文件
                    continue
                data = self.get_data(file_path)
                for index, row in data.iterrows():
                    sentence = cut_sentence.cut(row["content"], by_word=False, use_stopword=True)
                    sentence_list.append(sentence)
                    for word in sentence:
                        self.word_frequence_dict[word] = self.word_frequence_dict[word] + 1 # 往字典中添加word

        # 将词频保存到本地
        pickle.dump(self.word_frequence_dict, open(self.word_frequence_path, "wb"))
        logger.info("There are {} words in vocabs".format(len(self.word_frequence_dict)))
        # 将所有文本分词后的sentence列表保存到本地
        pickle.dump(sentence_list, open(self.sentence_list_path, "wb"))


    def get_data(self, path):
        """
        函数说明：加载数据
        :param path: 数据的路径
        """
        logger.info("pandas读取{}".format(path))
        data = pd.read_excel(path, header=None, names=["label", "content"]) # 通过pandas读取数据
        data = data.dropna(axis=0, how="any", subset=["content"]) # 删除空数据
        return data


    def word_frequence_statistics(self, word):
        """
        函数说明：词频统计方法，用于新增文本数据统计词频
        :param word: 词
        :return:
        """
        self.word_frequence_dict[word] = self.word_frequence_dict[word] + 1





