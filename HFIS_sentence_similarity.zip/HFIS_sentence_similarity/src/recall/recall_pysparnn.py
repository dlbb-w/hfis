"""
通过pysparnn对数据进行召回，得到粗排结果
Author: Shubao Zhao
email: machinelearner@126.com
"""
import sys
import os
cur_path = os.path.abspath(os.path.dirname(__file__))
root_path = os.path.split(cur_path)[0]
root_path = os.path.split(root_path)[0]
sys.path.append(root_path)
import math
import pickle
import pandas as pd
import time
import config
import pysparnn.cluster_index as ci
from tqdm import tqdm
from src.recall.sentence2vec import SentenceVectorizer

sen_vec = SentenceVectorizer()
class Recall_PySparNN:
    def __init__(self, recall_by="sum_avg"):
        self.root_path = config.root_path
        self.recall_by = recall_by
        self.cp_avg_path = os.path.join(self.root_path, "model/recall/cp_sum_avg_HF.pkl")
        # 加载保存到本地的句子向量
        if recall_by == "sum_avg":
            # 如果存在cp，则加载
            if os.path.exists(self.cp_avg_path):
                self.cp = pickle.load(open(self.cp_avg_path, "rb"))
            # 如果不存在，则创建
            else: # TODO 后期应该从数据库中读取
                files_path = os.path.join(self.root_path, "datasets/train/hf_data")
                self.cp = self.build_cp(files_path)

        elif recall_by == "SIF_weight":
            # TODO SIF加权模型尚未开始做
            cp_dump_path = os.path.join(self.root_path, "model/recall/cp_SIF_weight.pkl")
            if os.path.exists(cp_dump_path):
                self.cp = pickle.load(open(cp_dump_path, "rb"))
            else:
                files_path = os.path.join(self.root_path, "datasets/test/教育文体-教育行政管理-教学管理（含：课程、课时安排等）.xls")
                self.cp = self.build_cp(files_path)


    def insert_data(self, id, sentence):
        """
        函数说明：输入插入
        :param id: 工单id
        :param sentence:工单内容
        :return:
        """
        i = 0
        vector = sen_vec.get_sentence_vector(sentence)
        id_sentence = str(id) + "@@@" + sentence
        self.cp.insert(vector, id_sentence)


    def dump_cp(self):
        """
        函数说明，定期保存cp文件，防止丢失
        :return:
        """
        pickle.dump(self.cp, open(self.cp_avg_path, "wb"))


    def build_cp(self, files_path):

        """
        函数说明：构建pysparnn所需要的cp文件
        :param files_path: 原始数据路径
        :return: cp文件
        """
        id_sentence_list = [] # 存放id和文本拼接后的内容
        vector_list = [] # 存放向量
        for root, dirs, files in os.walk(files_path):
            for file in tqdm(files):
                file_path = os.path.join(root, file)
                print('file_path is:',file_path)
                # 过滤调不必要的文件
                if "DS_Store" in file_path:
                    continue
                # 通过pandas读取excel文件
                data = self.get_data(file_path)
                for index, row in data.iterrows():
                    # 遍历data中的数据
                    id = row["id"]
                    sentence = row["content"]
                    # 处理空数据
                    if type(sentence) == float:
                        if math.isnan(sentence):
                            # 如果文本内容为空，则跳过
                            continue
                    vector = sen_vec.get_sentence_vector(sentence) # 获取句子向量
                    vector_list.append(vector)
                    id_sentence_list.append(str(id) + "@@@" + sentence.strip())
        # 构建 cluster_index文件
        cp = ci.MultiClusterIndex(vector_list, id_sentence_list)
        pickle.dump(cp, open(self.cp_avg_path, "wb"))
        return cp


    def get_data(self, file_path):
        """
        函数说明：利用pandas读取excel文件
        :param file_path: excel文件路径
        :return: DataFrame数据类型的对象
        """
        data = pd.read_excel(file_path, header=0, names=["id", "type", "content"])
        return data


    def search(self, sentence, k=20, k_clusters=200, return_distance=False, recall_by="sum_avg"):
        """
        函数说明：实现快速近邻搜索
        :param sentence: 所需要搜索的句子，str
        :param k: 想要返回相似度最高的文本的个数，int
        :param k_clusters: 所需要聚类的个数 int
        :param return_distance: 是否需要返回距离 True or False
        :return:
        """
        if recall_by=="sum_avg":
            vector = sen_vec.get_sentence_vector(sentence)
            results = self.cp.search(vector, k, k_clusters, return_distance)
            return results
        elif recall_by=="SIF_weight":
            pass


    def recall_service_api(self, sentence, k=20, k_clusters=1, return_distance=False):
        """
        函数说明：召回的API接口
        :param query_vec:
        :param id_list:
        :param sentence_vec_list:
        :return:
        """
        vector = sen_vec.get_sentence_vector(sentence)
        results = self.cp.search(vector, k, k_clusters, return_distance)
        return results


if __name__ == "__main__":
    rp = Recall_PySparNN(recall_by="sum_avg")
    begin_time = time.time()
    sentence  = "重复来电：来电人为当涂县塘南镇白马行政村三年吴自然村160号村民，反映自己患有三级精神疾病，眼睛近视1600度，无法正常工作，向村委会申请低保无果，望处理。【同单号20010860130057】"
    results = rp.search(sentence)
    end_time = time.time()
    print("耗时：", end_time-begin_time)
    for result in results:
        for sentence in result:
            print(sentence)

