
import numpy as np
from src.utils import cut_sentence
from config import vec_model


"""实现将句子转化为句子向量"""
class SentenceVectorizer:
    def __init__(self):
        """
        函数说明：初始化，并加载w2v词向量
        """
        pass


    def fit_transform(self, sentences):
        """
        函数说明：处理历史数据
        :param sentences: 文本列表[sentence, sentence,...]
        :return:
        """
        lines_vectors = self.fit(sentences)
        return lines_vectors


    def fit(self, lines):
        """函数说明：将文件中所有的句子均转换为向量格式"""
        lines_vectors = []
        for line in lines:
            vector = self.get_sentence_vector(line)
            lines_vectors.append(vector)
            self.fited = True
        return lines_vectors


    def get_sentence_vector(self, line):
        """函数说明：获取sentence的向量"""
        # 分词
        word_list = cut_sentence.cut(line.strip(), by_word=False, use_stopword=True, with_sg=False)
        # 求和取平均
        vector = np.zeros(300)
        for word in word_list:
            vector += self.get_word_vector(word)
        vector = vector / len(word_list)
        # 返回句子向量
        return vector


    def get_word_vector(self, word):
        """函数说明：获取词向量"""
        try:
            return vec_model[word]
        except:
            return np.zeros(300)


    def transform(self, sentence):
        """
        函数说明：处理用户输入的数据
        :param sentence: str
        :return:
        """
        line_vector = self.get_sentence_vector(sentence)
        return line_vector
