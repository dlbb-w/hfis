import string
import jieba.posseg as psg
import jieba
import config


jieba.load_userdict(config.root_path + "/stopwords/dict.txt")
letters = string.ascii_lowercase + "0" + "1" + "2" + "3" + "4" + "5" + "6" + "7" + "8" + "9"
from src.utils.stopwords import stopwords

def cut(sentence, by_word=False, use_stopword=False, with_sg=False):
    """
    函数说明：切分词
    :param sentence: 句子
    :param by_word: 是否按照单个字进行分词，默认为False
    :param use_stopword: 是否使用停用词，默认为False
    :param with_sg: 是否返回词性
    :return:
    """
    if by_word:
        # 如果按照单个字进行划分，则调用cut_sentence_by_word
        result = cut_sentence_by_word(sentence)
    else:
        result = psg.lcut(sentence) # 返回词性，posseg.lcut()方法提供了每个词的词性，方便对句法做分析
        result = [(i.word, i.flag) for i in result] # i.word：词， i.flag：词性
        if not with_sg:
            # 如果不要词性，就返回词，舍弃词性
            result = [i[0] for i in result]

    # 是否使用停用词
    if use_stopword:
        if with_sg:
            result = [i for i in result if i[0] not in stopwords] # 如果i不在result中，则存入列表
        else:
            result = [i for i in result if i not in stopwords] # 如果i不在result中，则存入列表

    if with_sg:
        # TODO 此result为后加的
        result = [(i[0].strip(), i[1]) for i in result if len(i[0].strip()) > 0]
    else:
        # TODO 此result为后加的
        result = [i.strip() for i in result if len(i.strip()) > 0]

    return result




def cut_sentence_by_word(sentence):
    """
    函数说明：使用jieba对sentence进行分词
    :param sentence: 待分词的句子
    :return:
    """
    result = []
    temp = ""
    for word in sentence:
        if word.lower() in letters:
            # 如果是英文字母，则进行拼接，不进行分割
            temp += word
        else:
            if temp != "":
                # 如果temp不为空，则存入result中，并置为空
                result.append(temp.lower())
                temp = ""
            result.append(word.strip())

    # 最后再判断一下temp是否为空，如果不为空，则append到result中
    if temp != "":
        result.append(temp)

    return result

