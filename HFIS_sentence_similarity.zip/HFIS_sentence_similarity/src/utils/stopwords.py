from config import root_path

stopword = open(root_path + "/stopwords/stopwords.txt", encoding="utf-8").readlines() # 读取停用词
stopwords = [i.strip() for i in stopword] # 读取停用词路径，存入列表中

