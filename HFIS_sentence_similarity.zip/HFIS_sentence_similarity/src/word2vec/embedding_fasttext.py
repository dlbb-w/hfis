from similarity_sentence import config
from similarity_sentence.src.utils import cut_sentence
import os
import xlrd
import openpyxl
from gensim import models
from gensim.models.word2vec import LineSentence
from tqdm import tqdm


class Embedding:
    """
    实现一个Embedding类，训练词向量
    """
    def __init__(self, by_word=False):
        print("训练fasttext词向量....................")
        self.root_path = config.root_path
        self.original_data = os.path.join(self.root_path, "train/train_not_split.txt")
        self.original_path = os.path.join(self.root_path, "datasets\训练工单")  # 数据集路径
        if by_word:
            self.train_file_path = os.path.join(self.root_path, "train/train_by_word.txt")
        else:
            self.train_file_path = os.path.join(self.root_path, "train/train.txt")
        self.stopwords = open(self.root_path + "/stopwords/stopwords.txt", encoding="utf-8").readlines() # 读取停用词
        self.by_word = by_word
        print("加载数据......................")

    def load_data(self):
        """
        函数说明：读取数据文件
        :return:
        """
        print("读取数据文件.........")
        f = open(self.train_file_path, "w+", encoding="utf-8") # 打开要写入的训练集路径
        f2 = open(self.original_data, "w+", encoding="utf-8")
        # 遍历该路径下的每一个数据集，files为数据集名称所组成的集合
        for root, dirs, files in tqdm(os.walk(self.original_path)):
            # 遍历每一个数据集
            for file in files:
                file_path = os.path.join(root, file)
                print("file_path = ", file_path)
                if "xlsx" in file_path:
                    wb = openpyxl.load_workbook(file_path)
                    ws = wb.active
                    for line in ws:
                        data = line[1].value
                        if data is None:
                            continue
                        if len(data) <= 1:
                            continue
                        f2.write(data+"\n")
                        result = cut_sentence.cut(data, by_word=self.by_word, use_stopword=True, with_sg=False)
                        for char in result:
                            f.write(char + "\t")
                        f.write("\n")
                else:
                    data = xlrd.open_workbook(file_path)  # 读取xls文件
                    table = data.sheets()[0]
                    nrows = table.nrows  # 获取表的行数
                    # 遍历文件中的数据
                    for i in range(1, nrows):
                        sentence = table.row_values(i)[1]
                        result = cut_sentence.cut(sentence, by_word=self.by_word, use_stopword=True, with_sg=False)
                        for char in result:
                            f.write(char + "\t")
                        f.write("\n")
        f.close()
        f2.close()
        print("读取完成............................")

    def train_fasttext(self):
        """
        函数说明：fasttext训练词向量
        :return:
        """
        print("训练fasttext词向量...................")

        self.fast = models.FastText(LineSentence(self.train_file_path),
                                    size=128,  # 向量维度
                                    window=3,  # 移动窗口
                                    alpha=0.03,
                                    min_count=2,  # 对字典进行截断，小于该数的则会被切掉，增大该值可以减少词表个数
                                    iter=15,  # 迭代次数
                                    max_n=3,
                                    word_ngrams=2,
                                    max_vocab_size=5000
                                    )
        print("词向量训练完成............................")

    def save_fasttext(self):
        """
        函数说明：保存word2vec训练的词向量
        :return:
        """
        print("保存词向量模型..............................")
        if self.by_word:
            self.fast.wv.save_word2vec_format(self.root_path + "/model/embedding/fast_by_word.bin", binary=False)
        else:
            self.fast.wv.save_word2vec_format(self.root_path + "/model/embedding/fast.bin", binary=False)


    def load_fasttext(self):
        """
        函数说明：加载word2vec训练的词向量
        :return:
        """
        if self.by_word:
            self.fast = models.KeyedVectors.load_word2vec_format(
                self.root_path + "/model/embedding/fast_by_word.bin", binary=False)
            return self.fast
        else:
            self.fast = models.KeyedVectors.load_word2vec_format(
                self.root_path + "/model/embedding/fast.bin", binary=False)
            return self.fast



if __name__ == "__main__":
    em = Embedding(by_word=False)
    # em.load_data()
    em.train_fasttext()
    em.save_fasttext()





















