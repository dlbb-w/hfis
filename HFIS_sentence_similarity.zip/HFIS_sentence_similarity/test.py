import pysparnn.cluster_index as ci
import pickle

cp_dump_path = "/Users/shubao/PycharmProjects/HFIS_sentence_similarity/model/recall/test.pkl"



cp = pickle.load(open(cp_dump_path, "rb"))

cp.insert([2,2,3,4,5], "123@你好")
cp.insert([1,2,3,3,7], "123@阿尼哈谁有")
cp.insert([5,5,5,5,5], "123@你好ya")
pickle.dump(cp, open(cp_dump_path, "wb"))

cp = pickle.load(open(cp_dump_path, "rb"))





result = cp.search([1,2,3,4,5], k=10, k_clusters=1)
print(result)

