1. shiduAPI.py : 将crime.txt中的罪名从shidu的接口导出其对应的question,sim_question,answer, 生成search.json

2. dict.py ： 将search.json文件的格式转成嵌套字典，加上标号（0，1，2，...），加上key(question,similar question)和value(answer)

3. question_answer_robot.py : 通过比较输入的question和预料中的question的相似度，返回前五个相似度最高的sim_question以及对应的answer

4. server.py : 接口文件，接受string类型的问题，返回五个相似度最高的问题以及答案