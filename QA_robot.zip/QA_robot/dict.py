import json
with open('search.json') as f:
    data = json.load(f)

result_dict = {}
count = 0
for i in data.items():
    for sim_question in i[1].items():
        # count += 1
        res = {'question':i[0],'sim_question':sim_question[0],'answer':sim_question[1][0]}
        result = {str(count):res}
        result_dict.update(result)
        count += 1
print(result_dict)

js = json.dumps(result_dict, indent=4, ensure_ascii=False)  # indent参数是换行和缩进
fileObject = open('qa_dict.json', 'w')
fileObject.write(js)
fileObject.close()  # 最终写入的json文件格式:

