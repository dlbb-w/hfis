import os
import json
import jieba
import gensim


class QArobot:
    def  __init__(self, sentence):
        self.sentence = sentence

    def split_word(sentence, stoplist=[]):
        '''分词+删除停用词，返回列表'''
        words = jieba.cut(sentence)
        stopwords = ','.join(stoplist)
        result = [i for i in words if i not in stopwords]
        return result


    # 打开语料库
    def load_data(self):
        with open('qa_dict.json') as f:
            data = json.load(f)
        return data

    # 停用词
    def stopwords(self):
        with open('data/stopwords.txt', encoding='utf-8') as f:
            stoplist = f.read().splitlines()
        return stoplist

    # 加载分词结果
    def split_words(self):
        splitdata_filepath = './data/splitdata.json'
        with open(splitdata_filepath, encoding='utf-8') as f:
            content = json.load(f)
        return content

    # 加载生成的gensim字典
    def load_gensim(self):
        dictionary_filepath = './data/dictionary'
        dictionary = gensim.corpora.Dictionary.load(dictionary_filepath)
        return dictionary

    # 加载tfidf模型
    def load_tfidf_model(self):
        model_filepath = './data/tfidf.model'
        tfidf = gensim.models.TfidfModel.load(model_filepath)
        return tfidf

    # 加载tfidf相似度比较序列
    def load_tfidf_index(self):
        index_filepath = './data/tfidf.index'
        index = gensim.similarities.Similarity.load(index_filepath)
        return index

    def qa(sentence):
        stoplist = QArobot(sentence).stopwords()
        words = QArobot.split_word(sentence, stoplist)  # 分词
        vec = QArobot(sentence).load_gensim().doc2bow(words)  # 转词袋表示
        tfidf = QArobot.load_tfidf_model(sentence)
        sims = QArobot(sentence).load_tfidf_index()[tfidf[vec]]  # 相似度比较
        sorted_sims = sorted(enumerate(sims), key=lambda x: x[1], reverse=True)  # 逆序
        print('分词结果 ->  ', words)
        print("相似度比较 ->  ", sorted_sims[:5])
        for i, similarity in sorted_sims[:5]:
            print(similarity, QArobot.load_data(sentence)[str(i)])


if __name__ == '__main__':
    robot = QArobot.qa(sentence= '聚众斗殴？')

