#!/usr/bin/env python
# _*_coding:utf-8 _*_

import os
import sys

cur_path = os.path.abspath(os.path.dirname(__file__))
root_path = os.path.split(cur_path)[0]
sys.path.append(os.path.split(root_path)[0]+"/classification")

from flask import Flask, request, abort
import json
import question_answer_robot

app = Flask(__name__)

def qa_api(sentence):
    robot = question_answer_robot.QArobot.qa(sentence)
    return robot

@app.route('/kng_search_model', methods=['POST'])
def kng_search():
    """
    输入string格式
    """
    try:
        sentence = '聚众斗殴？'
        es_sen_dict = question_answer_robot.QArobot.qa(sentence)
    except Exception as err:
        print('err is:', err)
        abort(500)
    response = {}
    response['es_dict'] = es_sen_dict
    return json.dumps(response)

if __name__ == '__main__':
    app.run(host="0.0.0.0", port="8082", debug=True)

