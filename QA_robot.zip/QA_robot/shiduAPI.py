import requests
import json
#
#获取token
def get_token():
    token_url = 'http://openapi.shiduai.com:10001/oauth/token'
    token_body = {'grant_type': 'password', 'username': 'hlj_openapi', 'password': 'heilongjiang@shiduai'}
    token_headers = {'Authorization': 'Basic bXktdHJ1c3RlZC1jbGllbnQ6c2VjcmV0', 'Content-Type': 'application/x-www-form-urlencoded'}
    post_result = requests.post(token_url, token_body, headers=token_headers)
    post_result = json.loads(post_result.content)
    bearer = post_result['token_type'] + ' ' + post_result['access_token']
    return bearer

#获取相似问题
def get_question_similarList(question,bearer):
    question_url = 'http://openapi.shiduai.com:10001/robot/visit/ask/new'
    question_body = {'question': question}
    question_headers = {'Authorization': bearer, 'Referer': 'http://openapi.shiduai.com:10001/robot/visit/ask/new'}
    question_result = requests.post(question_url, json=question_body, headers=question_headers)
    question_result = json.loads(question_result.content)
    question_similarList = question_result['data']['similarList']
    # print(question_similarList)
    return question_similarList

#获取案件列表
def  get_list(question,bearer):
    question_url = 'http://openapi.shiduai.com:10001/robot/visit/ask/new'
    question_body = {'question': question}
    question_headers = {'Authorization': bearer, 'Referer': 'http://openapi.shiduai.com:10001/robot/visit/ask/new'}
    question_result = requests.post(question_url, json=question_body, headers=question_headers)
    question_result = json.loads(question_result.content)
    question_similarList = question_result['data']['similarList']
    if question_similarList is None:
        print('没有数据')
        return
    for case in question_similarList:
        # print(case)
        return get_content(case,bearer)

#遍历案件
def get_content(case,bearer):
    content_url = 'http://openapi.shiduai.com:10001/robot/visit/ask/new'
    content_body = {'question': case}
    content_headers = {'Authorization':bearer,'Referer':'http://openapi.shiduai.com:10001/robot/visit/ask/new'}
    content_result = requests.post(content_url, json=content_body, headers=content_headers)
    content_result = json.loads(content_result.content)
    answer = content_result['data']['answer']
    # print(answer)
    return answer


##问题
question_file = open('D:\experiment\\test\data\crime.txt',encoding='utf-8')
question_list=[]
question_similar_List=[]
search_dict = {}

for line in question_file.readlines():
    question_list.append(line.replace('\n',''))
index = 0
for i,question in enumerate(question_list):
    index = i+0
    print('index is:',index)
    answer_list = []
    bearer = get_token()
    answer_list.append(get_list(question,bearer))
    # print(question,answer_list)
    # search_dict[question] = answer_list
    question_similar_List = get_question_similarList(question,bearer)
    try:
        for question_similar in question_similar_List:
            search_dict.setdefault(question, {})[question_similar] = answer_list
            print(search_dict)
    except:
        continue
# print(question_similar_List)
#
# js = json.dumps(search_dict, indent=4, ensure_ascii=False)  # indent参数是换行和缩进
# fileObject = open('search.json', 'w')
# fileObject.write(js)
# fileObject.close()  # 最终写入的json文件格式:

# qa_dict = {'question
# question='被人打了怎么办'
# bearer = get_token()
# get_list(question,bearer)